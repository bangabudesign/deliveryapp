<template>
    <v-app>
        <v-main>
            <router-view></router-view>
        </v-main>
    </v-app>
</template>
<script>

export default {
    data() {
        return {
            message: 'Hello World'
        }
    }
};
</script>